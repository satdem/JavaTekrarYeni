package gun7;

public class StringToLowerCase {

    /*
    toLowerCase()

    Converts a string to lower case letters

    String
    */

    public static void main(String[] args) {

        String text = "HELLO worlD!!!";
        System.out.println( text.toLowerCase() );

    }

}
