package gun7;

public class StringToString {

    /*
     toString()

     Returns the value of a String object

     String
     */

    public static void main(String[] args) {
        String text = "Some cool text";

        System.out.println( text.toString() );
    }
}
