package gun7;

public class Task1 {
    // print your name in "UPPERCASE" and surname in "lowercase"

    public static void main(String[] args) {
        String name = "Michael";
        String surname = "Jackson";

        System.out.println( "name: " + name.toUpperCase() );
        System.out.println( "surname: " + surname.toLowerCase() );
    }
}
