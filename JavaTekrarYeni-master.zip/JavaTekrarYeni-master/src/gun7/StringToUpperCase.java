package gun7;

public class StringToUpperCase {

    /*
     toUpperCase()

     Converts a string to upper case letters

     String
    */

    public static void main(String[] args) {

        String text = "HELLO worlD!!!";
        System.out.println( text.toUpperCase() );

    }

}
