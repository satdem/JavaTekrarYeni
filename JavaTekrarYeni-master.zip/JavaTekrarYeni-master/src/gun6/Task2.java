package gun6;

public class Task2 {
    // create a string with value "admin@techno.study"
    // search for the "study" and return its index;
    public static void main(String[] args) {

        String email = "admin@techno.study";
        System.out.println(email.indexOf("study"));

    }
}
