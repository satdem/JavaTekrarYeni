package gun6;

public class StringLength {

    /*
    length()

    Returns the length of a specified string
    Belli bir Stringin uzunlugunu int olarak verir.
    int
     */

    public static void main(String[] args) {
        String text = "Todays Weather";
        System.out.println( "Length of the text is: " + text.length() );
    }

}
