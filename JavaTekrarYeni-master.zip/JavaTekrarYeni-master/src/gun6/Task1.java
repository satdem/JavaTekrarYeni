package gun6;

public class Task1 {
    // create variable with data type string
    // write your name and print its length
    public static void main(String[] args) {

        String ismim = "Samil Balci";

        String text1 = "ismimin";
        String text2 = "uzunlugu";

        String sonuc = text1+" "+ text2+" " + ismim.length();

        System.out.println(sonuc+ " karakterdir.");
    }
}
