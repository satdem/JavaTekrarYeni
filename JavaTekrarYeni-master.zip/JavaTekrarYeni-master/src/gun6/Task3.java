package gun6;

public class Task3 {
    //create two variables as first name , and last name
    // print initials of your name
    // input:
    // a = Michael
    // b = Jackson

    // output:
    // M.J.
    public static void main(String[] args) {
        String a = "Samil";
        String b = "Balci";

        System.out.println(a.charAt(0)+"."+b.charAt(0)+".");
    }
}
