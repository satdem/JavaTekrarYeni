package gun10;

public class JavaIfStatement {

    public static void main(String[] args) {

        int num = 150;

        // if(condition-Durum) {
        // Belirtilen durum icin gecerli olan calisacak kod blogumuz
        // }

        if(num > 10) { //code block
            System.out.println( "You have number which is greater than 10" );
        }

        if(num > 15) {
            System.out.println( "You have number which is greater than 15" );
        }

    }

}
